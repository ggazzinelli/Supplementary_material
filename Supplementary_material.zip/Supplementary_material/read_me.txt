

-In cutting patterns we include the patterns generated for Formulation 1.

-In Complete results we include  the complete results containing all the solutions found.

-In Suplementary material we include  a extended literature review, some additional details on the implementation of Algorithm 2, 
some special cases of the CSP-SOS and the proofs of the propositions presented in the paper.

